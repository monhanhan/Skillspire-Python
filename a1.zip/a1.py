def main():

    name = "Ryan Munin"

    if name.endswith("Munin"):
        print("This ends with the correct last name.")

    username = "PeePeePooPooMan420"

    if username.isalnum():
        print("The username is Alphanumeric")


main()
